# Deliverability guide — US DTC brands — 15 sample leads

One page. Keep it boring and consistent.

## Before the first send
- Send from a real business address on a domain you control, not a free mailbox.
- Publish SPF, DKIM and DMARC. Start with DMARC `p=none`, then tighten.
- Warm the inbox for 7 days: 10–20 manual emails/day to real contacts who reply.
- Verify every address before loading it. This pack marks each contact `valid`,
  `catch_all`, `risky`, or `needs_manual`; never send to `needs_manual`.

## Daily rhythm
- 10–15 cold emails per inbox per day, 5 days per week, 8–11am local time.
- One inbox = one sender identity. Do not rotate domains into the same thread.
- Plain text only: no images, no tracking pixel, no HTML signature, at most one link.
- Include a real sender name, business address, and a working opt-out line.

## List hygiene
- Suppress unsubscribes and hard bounces permanently, before the next batch.
- Replace invalid addresses free for 7 days; the replacement must pass the same checks.
- Remove role addresses that bounce and any domain that asks not to be contacted.
- Stop the sequence on any reply, including "not now".

## What to watch
- Bounce rate above 3%: pause, clean the list, re-check MX and catch-all domains.
- Spam complaints above 0.1%: pause, rewrite the offer, reduce volume.
- Replies that ask "how did you get my email": answer with the public source URL.
- Open rates are not a reliable signal with tracking off. Measure replies and calls.

## Safe copy rules
- No fake urgency, guarantees, invented clients, or invented results.
- One clear CTA per email. Follow-ups use a new angle, never "just checking in".
- Quote only public facts you can link to in the evidence column.
