<!-- Pack: US DTC brands — 15 sample leads | client: sample review | leads: 15 -->

# 3-email sequence — Pipeline Pack lead pack

Load these into Instantly, Smartlead, Brevo, or HubSpot. Plain text only.
Replace `{{first_name}}`, `{{company}}`, and `{{observation}}` from the CSV.
Keep one link maximum. Stop on reply. Suppress unsubscribes permanently.

## Day 0 — free sample

**Subject:** 15 leads for {{company}}

Hi {{first_name}},

I saw that {{observation}}. I build lead packs for e-commerce/CRO agencies:
150 verified B2B leads, 150 personalized first lines, and a 3-email sequence,
delivered in 48 hours.

I can send 15 free sample leads for {{company}}'s exact ICP first. Want me to?

{{sender_name}}
{{website}}
If this is not relevant, reply "no" and I will not contact you again.

## Day 3 — new angle, same thread

**Subject:** Re: 15 leads for {{company}}

Hi {{first_name}},

Different angle: {{observation_2}}. That public signal is why I picked
{{company}} rather than a generic list.

If {{company}} is taking on new e-commerce work this month, I can send 15 free
sample leads for your exact ICP. Should I send them?

{{sender_name}}
{{website}}
If this is not relevant, reply "no" and I will remove you.

## Day 7 — price and delivery

**Subject:** Re: 15 leads for {{company}}

Hi {{first_name}},

Last note from me. The full pack is 150 verified B2B leads for {{company}}'s
ICP, 150 first lines, and a 3-email sequence. It is $149, or $134 paid upfront,
delivered 48 hours after deposit.

If you want the 15-lead sample first, reply "sample" and I will send it.

{{sender_name}}
{{website}}
If this is not relevant, reply "no" and I will close the loop.

## Deliverability notes

- Send 10–15 emails per inbox per day, 5 days per week, 8–11am local time.
- Plain text. No images, no tracking pixel, at most one link.
- Use a real sender name, business address, and working opt-out.
- Warm the inbox for 7 days before the first batch.
- Suppress bounces, unsubscribes, current clients, and competitors immediately.
- Do not use a centralized stablecoin or card rail in any invoice. Payment rails
  are SOL, ETH (L1/Base), BTC on-chain/Lightning, ZEC shielded, or XMR only.


## Merge fields

`{{first_name}}`, `{{company}}`, `{{observation}}`, `{{observation_2}}`, `{{sender_name}}`, `{{website}}`. The per-lead first line is in `leads.csv`.
