PIPELINE PACK — US DTC brands — 15 sample leads
Generated: 2026-11-25 07:01 UTC
Prepared for: sample review
Leads: 15

FILES
  leads.csv             company, website, contact path, source URL, evidence, first line
  first_lines.csv       company + personalized first line + source URL
  email_sequence.md     3-email sequence with merge fields and send rules
  deliverability_guide.md   one-page setup and hygiene guide
  MANIFEST.json         machine-readable pack summary

WHAT EVERY ROW MEANS
  source_url            the public page that names the company and its fit
  evidence_snippet      the exact public claim used, not a paraphrase
  first_line_source_url the page the first-line observation came from
  email_status          valid / catch_all / risky / needs_manual, with method stored in the DB
  contact_form          use this when email is blank or needs manual verification

GUARANTEES
  - No invented companies, names, titles, emails, observations, case studies, or metrics.
  - Invalid email addresses are replaced free for 7 days after delivery.
  - One revision included.
  - Full CSV is released only after the balance is confirmed.

SOURCE NOTE
  Public Shopify editorial and case-study pages, plus each brand's own public website.

PAYMENT
  This pack is a free sample unless an invoice says otherwise. Paid work is quoted in USD
  and settled in SOL, ETH (L1/Base), BTC on-chain/Lightning, shielded ZEC, or XMR.
  No stablecoins, cards, or marketplaces.
